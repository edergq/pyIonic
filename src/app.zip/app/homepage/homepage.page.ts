import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, MenuController, ModalController, NavController, Platform } from '@ionic/angular';
import { BasicApiService } from 'src/Providers/Basic/basic-api.service';
import { CartApiService } from 'src/Providers/Cart/cart-api.service';
import { LocalApiService } from 'src/Providers/Local/local-api.service';
import { ApiService } from 'src/Providers/Services/api.service';
import { Location } from "@angular/common";
import * as $ from 'jquery';
import { AppVersion } from '@ionic-native/app-version/ngx';
import { environment } from '../../environments/environment';
import { InAppBrowser } from '@ionic-native/in-app-browser/ngx';
import { ItemdetailsPage } from '../itemdetails/itemdetails.page';
import { LoginpagePage } from '../loginpage/loginpage.page';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.page.html',
  styleUrls: ['./homepage.page.scss'],
})
export class HomepagePage implements OnInit {
  homepage: string;
  Servicesshow: boolean   = true;
  Offersshow: boolean     = false;
  Reviewshow: boolean     = false;
  slideOpts = {
    initialSlide: 0,
    autoplay: true,
    loop: true,
    speed: 1000,
    effect: 'fade',
    spaceBetween: 10,
    slidesPerView: 1.1,
    slidesPerColumn: 1,
    pagination: false,
  };
  slideOptsmenu = {
    initialSlide: 0,
    autoplay: false,
    loop: false,
    speed: 2000,
    effect: 'fade',
    spaceBetween: 10,
    slidesPerView: 2.5,
    pagination: false,
  };
	category: any;
	imgpath: any;
	mycart: any;
	cartcount: any;
	nowqty:any;
	nowval: any;
  carttotal: any;
  banners: any;
  postdata: any = {};
  getappsetng: any;
  isShopclose: any = false;
  closetxt: any;
  restrictns_lbl: any;
  restrictns_txt: any;
  isRestricktn: any = false;
  logeduser: any;
  nowapversion: string;
  ipbroptions: any = {};
  sesinlefct: any = false;
  appstngs: any = {};
  apptitle: any;
  newcategory: any = {};
  constructor(
    public menuCtrl: MenuController,
    public apiService: ApiService,
    public basic: BasicApiService,
	  public localApi: LocalApiService,
	  public cart: CartApiService,
    public route: Router,
    public alertController: AlertController,
    public location: Location,
    public modalController: ModalController,
    public nav: NavController,
    private appVersion: AppVersion,
    private iab: InAppBrowser,
    private platform: Platform
  ) { }

  ngOnInit() {
    this.homepage               = "Services";
    this.imgpath                = environment.imagepath;
    this.apptitle               = environment.appname;
    this.logeduser              = this.localApi.getuser();
    this.gethomecat();
    this.apiService.getdata('getappsetings', '').subscribe((resp: any) => {
      this.localApi.setappseting(resp.data);
      this.appstngs             = resp.data;
      if(resp.data.opentime.toDayShop=='CLOSE'){
        this.isShopclose        = true;
        this.closetxt           = resp.data.opentime;
      }
      if(resp.data.restrictions_label){
        this.restrictns_lbl     = resp.data.restrictions_label;
        this.restrictns_txt     = resp.data.restrictions_text;
        this.isRestricktn       = true;
      }
      var self = this;
      this.appVersion.getVersionNumber().then(function (data) {
        console.log("ok version");
        if(self.platform.is('android')){
          if(resp.data.androidversion > data){
            self.appupdatesandroid();
          }
        } else {
          console.log("resp.data.iosversion",resp.data.iosversion);
          console.log("data",data);
          if(resp.data.iosversion > data){
            self.appupdatesios();
          }
        }
      });

    }, (err: any) => {
    return false;
    });
  }

  async pophomepalrt() {
    const alert = await this.alertController.create({
      cssClass: 'my-custom-class',
      // header: 'Alert',
      subHeader: this.appstngs.pop_head,
      message: this.appstngs.pop_desc,
      buttons: ['OK']
    });

    await alert.present();

    const { role } = await alert.onDidDismiss();
  }

  async appupdatesandroid() {  
    const alert = await this.alertController.create({
      header: 'Update Available!',
      cssClass: 'my-custom-class',
      message: 'Please update the app to get the latest features, offers and discounts.',
      buttons: [
        {
          text: 'Not Now',
          role: 'cancel',
          cssClass: 'secondary',
          handler: (blah) => {
            console.log('Confirm Cancel: blah');
          }
        },
        {
          text: 'OK',
          handler: () => {
            const browser = this.iab.create(environment.playstore, '_system');
          }
        }
      ]
    });
    await alert.present();
  }

  async appupdatesios() {  
    const alert = await this.alertController.create({
      header: 'Update Available!',
      cssClass: 'my-custom-class',
      message: 'Please update the app to get the latest features, offers and discounts.',
      buttons: [
        {
          text: 'Not Now',
          role: 'cancel',
          cssClass: 'secondary',
          handler: (blah) => {
            console.log('Confirm Cancel: blah');
          }
        },
        {
          text: 'OK',
          handler: () => {
            const browser = this.iab.create(environment.appstore, '_system');
          }
        }
      ]
    });
    await alert.present();
  }

  noshopping(){
    this.isShopclose = false;
    if(this.restrictns_lbl){
      this.isRestricktn = true;
    }
  }

  gomyacount() {
    this.route.navigate(['/myaccount/any']);
  }

  async openloginpanel() {
    const modal = await this.modalController.create({
      component: LoginpagePage,
      cssClass: 'my-custom-class',
      backdropDismiss: true
    });
    modal.onDidDismiss().then((data) => {
      if (data.data) {
        this.logeduser = this.localApi.getuser();
        this.route.navigate(['/myaccount/any']);
      }
    });
    return await modal.present();
  }

  alrestclose(){
    this.isRestricktn = false;
  }

  ionViewWillEnter(){
    this.logeduser              = this.localApi.getuser();
    this.mycart = this.cart.getcart();
    console.log("this.cart.getcart()",this.cart.getcart());
    this.carttotal = this.cart.getTotalCart();
    this.cartcount = this.mycart.length;
    this.getappsetng = this.localApi.getappseting();
    this.localApi.removedeltime();
    let views = localStorage.getItem(environment.storage_prefix+'bktohome');
    if(views){
      this.gethomecat();
    }

    this.basic.getObservable().subscribe((data) => {
        this.totlaofcart();
    });

  }

  viewsearpg(){
    this.route.navigate(['/itemsearch']);
  }

  totlaofcart(){
    this.mycart = this.cart.getcart();
    this.carttotal = this.cart.getTotalCart();
    this.cartcount = this.mycart.length;
  }

  gethomecat(){
    localStorage.removeItem(environment.storage_prefix+"bktohome");
    this.totlaofcart();
    this.basic.presentLoading();
    this.apiService.getdata('gethomecategory', '').subscribe((resp: any) => {
    this.category = resp.data;
    console.log("resp.data",resp.data);
    for(let i=0; i < this.category.length; i++){

      let prd = this.category[i].prd;
          for(let j=0; j < prd.length; j++){
            let single = prd[j];
            let qty = this.cart.getSingleQty(single.id);
            this.category[i].prd[j].qty = qty;
            this.category[i].prd[j].crtbtn = 'Select';
            if(this.category[i].prd[j].hours_time){
              this.category[i].prd[j].corner_text = this.category[i].prd[j].hours_time+' Hour';
            }
            if(this.category[i].prd[j].minutes_time){
              this.category[i].prd[j].corner_text = this.category[i].prd[j].minutes_time+' Minutes';
            }
            if(this.category[i].prd[j].hours_time && this.category[i].prd[j].minutes_time){
              this.category[i].prd[j].corner_text = this.category[i].prd[j].hours_time+' Hour '+this.category[i].prd[j].minutes_time+' Minutes';
            }
        }
        if(i === 0){
          
          this.segmentChanged(this.category[i].id,'0');
        }
      }
      setTimeout(()=>{
        this.sesinlefct = true;
        if(this.basic.isLoading){
          this.basic.dismissloader();
        }
      },5000)
      
    }, (err: any) => {
      this.basic.dismissloader();
    return false;
    });

    this.apiService.postdata('getbanner', this.postdata).subscribe((resp: any) => {
      this.banners = resp.data;
    }, (err: any) => {
      return false;
    });
    
  }

  segmentChanged(id,ii){
    for(let i=0; i < this.category.length; i++){
      if(this.category[i].id == id){
        if(ii == 0){
          console.log("0",ii);
          this.category[i].segstyle = 'segment-button-checked';
        }
        else{
          console.log("0",ii);
          this.category[0].segstyle = '';
        }
        let prd = this.category[i].prd;
        for(let j=0; j < prd.length; j++){
          let single = prd[j];
          let qty = this.cart.getSingleQty(single.id);
          this.category[i].prd[j].qty = qty;
          this.category[i].prd[j].crtbtn = 'Select';
          if(this.category[i].prd[j].hours_time){
            this.category[i].prd[j].corner_text = this.category[i].prd[j].hours_time+' Hour';
          }
          if(this.category[i].prd[j].minutes_time){
            this.category[i].prd[j].corner_text = this.category[i].prd[j].minutes_time+' Minutes';
          }
          if(this.category[i].prd[j].hours_time && this.category[i].prd[j].minutes_time){
            this.category[i].prd[j].corner_text = this.category[i].prd[j].hours_time+' Hour '+this.category[i].prd[j].minutes_time+' Minutes';
          }
        }
        this.newcategory = this.category[i];
      }
    }
    console.log("this.newcategory",this.newcategory);
    console.log("newcategory.isscg",this.newcategory.isscg);
  }

  doRefresh(event) {
    setTimeout(() => {
      this.gethomecat();
      event.target.complete();
    }, 2000);
  }

  addtoCart(itm, itmid){
    console.log("itm.id",itm.id);
    console.log("itmid",itmid);
    $('#addcartbtn_'+itmid+'_'+itm.id).hide();
    $('#qtycartbtn_'+itmid+'_'+itm.id).show();
    $('#itmqty_'+itmid+'_'+itm.id).html('1');
    this.cart.addcart(itm,'','','');
    this.totlaofcart();
  }

  minusqty(itm, itmid){
    this.nowqty = '';
    this.nowval = '';
    this.nowqty = $('#itmqty_'+itmid+'_'+itm.id).html();
    if(this.nowqty == 1){
      $('#addcartbtn_'+itmid+'_'+itm.id).show();
    $('#qtycartbtn_'+itmid+'_'+itm.id).hide();
    }
    this.nowval = parseInt(this.nowqty)-1;
    $('#itmqty_'+itmid+'_'+itm.id).html(this.nowval);
    this.cart.minusqntyfrmprod(itm);
    this.totlaofcart();
    
  }
  addqty(itm, itmid){
    this.nowqty = '';
    this.nowval = '';
    this.nowqty = $('#itmqty_'+itmid+'_'+itm.id).html();
    this.nowval = parseInt(this.nowqty)+1;
    $('#itmqty_'+itmid+'_'+itm.id).html(this.nowval);
    $('#itmqty_'+itmid+'_'+itm.id).delay(1500).animate({text:this.nowval},5000);
    this.cart.plusqnty(itm);
    this.totlaofcart();
  }

  async openDetailsItem(itm) {
    const modal = await this.modalController.create({
      component: ItemdetailsPage,
      cssClass: 'my-custom-class',
      componentProps: {
        'item': itm,
      },
      backdropDismiss: true,
    });
    return await modal.present();
  }

  seeall(item){
    if(item.isscg){
      this.route.navigate(['/subcategory/'+item.id+'/'+item.name]);
    } else {
      this.route.navigate(['/products/'+item.id+'/0/'+item.name]);
    }
  }

  gocategory(item){
    if(item.type){
      if(item.type == 'category'){
        this.route.navigate(['/products/'+item.category.id+'/0/'+item.category.name]);
      } else if(item.type == 'contact'){
        this.route.navigate(['/contactus']);
      } else {
        this.route.navigate(['/offers/noapply']);
      }
    }
  }

  viewmycart(){
    this.route.navigate(['/booknow']);
  }

  openAlergyInfo(val){
    if(val.allergy_info){
      this.basic.alert('Allergy Info:', val.allergy_info);
    }
  }

  gonextsbg(sbct,cat){
    this.route.navigate(['/products/'+cat.id+'/'+sbct.id+'/'+sbct.name]);
  }

}
