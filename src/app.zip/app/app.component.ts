import { Component } from '@angular/core';
import { MenuController, ModalController, Platform } from '@ionic/angular';
import { Router } from '@angular/router';
import { ApiService } from 'src/Providers/Services/api.service';
import { LocalApiService } from 'src/Providers/Local/local-api.service';
import { LoginpagePage } from './loginpage/loginpage.page';
import { OneSignal } from '@ionic-native/onesignal/ngx';
import { environment } from '../environments/environment';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  public appPages = [
    { title: 'Home', url: '/homepage', icon:'home'},
    { title: 'Our Services', url: '/ourstylists', icon:'man'},
    { title: 'Make An Appointment', url: '/mybooking', icon:'calendar'},
    { title: 'Offers', url: '/offer/noapply', icon:'gift'},
    { title: 'Reviews / Ratings', url: '/reviewandrating', icon:'star-half'},
    // { title: 'Opening Hours', url: '/openinghours', icon:'time'},
    { title: 'About Us', url: '/listviews/About Us', icon:'information-circle'},
    { title: 'Help & Info', url: '/listviews/Help and Info', icon:'help-circle'},
    { title: 'Contact Us', url: '/contactus', icon:'call'},
    { title: 'Settings', url: '/listviews/Settings', icon:'settings'},
  ];
  appstngs: any;
  logeduser: any;
  postdata: any ={};
  constructor(
    private platform: Platform,
    public route: Router,
    public apiService: ApiService,
    public localApi: LocalApiService,
    private menu: MenuController,
    public modalController: ModalController,
    private oneSignal: OneSignal,
  ){
      this.initializeApp();
  }

  initializeApp() {
    this.apiService.getdata('getappsetings', '').subscribe((resp: any) => {
      this.localApi.setappseting(resp.data);
      this.appstngs       = resp.data;
    }, (err: any) => false);
    this.platform.ready().then(() => {
    this.oneSignal.startInit(environment.onesignalkey, environment.firebasekey);
    this.oneSignal.inFocusDisplaying(this.oneSignal.OSInFocusDisplayOption.InAppAlert);

    this.oneSignal.handleNotificationReceived().subscribe(() => {
      // do something when notification is received
    });
    this.oneSignal.handleNotificationOpened().subscribe((rsvnt) => {
      if (rsvnt.notification.payload.additionalData.type === 'Offers') {
        setTimeout(() => {
          this.route.navigate(['/offer/noapply']);
        }, 3000);
      }
    });

    this.oneSignal.promptForPushNotificationsWithUserResponse().then(() => {
      console.log('Hello My Name ', environment);
    });

    this.oneSignal.getIds().then(dvsid => {
      localStorage.setItem(environment.storage_prefix + 'userdevicetoken', dvsid.userId);
      this.setUserTokens(dvsid.userId);
    }).catch(err => {
      console.log('OneSGNLERR', err);
    });

    this.oneSignal.endInit();

    });
    this.logeduser = this.localApi.getuser();
  }

  setUserTokens(mytoken) {
    this.logeduser            = this.localApi.getuser();
    this.postdata.token       = mytoken;
    this.postdata.device      = 'Mobile';
    // this.postdata.device_type = this.device.platform;
    if(this.platform.is('android')){
      this.postdata.device_type = 'Android';
    }
    else{
      this.postdata.device_type = 'iOS';
    }
    this.postdata.user        = 'Customer';
    this.postdata.user_id     = '';

    this.apiService.postdata('setusertokens', this.postdata).subscribe((resp: any) => {
      console.log('Set Token', resp);
    }, (err: any) => false);
  }

  checklogin() {
    this.logeduser = this.localApi.getuser();
  }

  async openloginpanel() {
    this.menu.close();
    const modal = await this.modalController.create({
      component: LoginpagePage,
      cssClass: 'my-custom-class',
      backdropDismiss: true
    });
    modal.onDidDismiss().then((data) => {
      if (data.data) {
        this.logeduser = this.localApi.getuser();
        this.route.navigate(['/myaccount/any']);
      }
    });
    return await modal.present();
  }

  gomyacount() {
    this.menu.close();
    this.route.navigate(['/myaccount/any']);
  }

}
